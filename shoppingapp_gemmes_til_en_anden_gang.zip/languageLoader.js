// languageLoader.js
(async function loadLanguage() {
  try {
    // Hent hele sprogfils-objektet (f.eks. { da: {...}, en: {...} })
    const response = await fetch('lang.json');
    const allData = await response.json();

    // Brug lagret sprogkode, eller fallback til 'en'
    const savedLang = localStorage.getItem('selectedLang') || 'en';
    const translations = allData[savedLang] || allData['en'] || {};

    // Gør globale konstanter tilgængelige overalt
    window.currentLang = savedLang;
    window.translations = translations;

    // Forsøg at oversætte direkte, eller vent til DOM er klar
    if (typeof applyTranslations === 'function') {
      applyTranslations();
    } else {
      // Hvis applyTranslations ikke er defineret endnu, vent på DOM
      window.addEventListener('DOMContentLoaded', () => {
        if (typeof applyTranslations === 'function') applyTranslations();
      });
    }
  } catch (err) {
    console.error('Failed to load language file:', err);

    // Sikre globale defaults, så andre scripts ikke fejler
    window.currentLang = 'en';
    window.translations = {};
  }
})();
