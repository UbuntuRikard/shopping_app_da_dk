let translations = {};
// Variabel der gemmer sprog kode, hvis ingen så vælge en = engelsk
let currentLang = localStorage.getItem('selectedLang') || 'en';
let isEditing = false; // Holder styr på om en vare redigeres
let zeroMode = 0;

// 🔄 Indlæser oversættelser fra `lang.json`
async function loadTranslations() {
    try {
        const response = await fetch('lang.json');
        translations = await response.json();
        console.log("Oversættelser indlæst:", translations); // Debugging
        applyTranslations(); // Kører oversættelser ved start
    } catch (error) {
        console.error('Kunne ikke indlæse oversættelser:', error);
    }
}

// 🔄 **Anvend oversættelser til hele siden**
function applyTranslations() {
    if (!translations[currentLang] || !translations[currentLang].shop) {
        console.error("Oversættelser mangler:", translations);
        return;
    }

    const texts = translations[currentLang].shop;

    // Opdater HTML lang-attribut
    document.getElementById('htmlTag').setAttribute('lang', currentLang);

    // Opdater tekster i elementer med `data-i18n`
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (texts[key]) {
            el.textContent = texts[key];
        }
    });

    // Opdater placeholders i inputfelter
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        const key = el.getAttribute('data-i18n-placeholder');
        if (texts[key]) {
            el.placeholder = texts[key];
        }
    });

    updateButtonText(); // Opdater knapteksten efter oversættelse
}

// 🛠 **Opdater knapteksten baseret på redigeringstilstand**
// her mangler noget logik tilat styre og ændre tilstanden
function updateButtonText() {
    const addBtn = document.getElementById("addBtn");
    if (!addBtn) {
        console.error("Kunne ikke finde addBtn!");
        return;
    }

    const key = isEditing ? "Update item" : "Add item";
    const translation = translations[currentLang]?.shop?.[key];

    if (!translation) {
        console.error(`Mangler oversættelse for '${key}' i sprogfilen!`);
        return;
    }

    addBtn.textContent = translation;
    console.log(`Knaptekst opdateret til: '${translation}' på sprog '${currentLang}'`);
}

// 🔄 **Toggle-knap (Show all, Hide 0, Only 0)**
function toggleAndTranslate() {
    zeroMode = (zeroMode + 1) % 3;

    // Henter de korrekte oversættelser fra JSON-filen
    const labels = [
        translations[currentLang].shop["Hide 0"],
        translations[currentLang].shop["Only 0"],
        translations[currentLang].shop["Show all"]
    ];

    // Opdater knaptekst med oversættelse
    document.getElementById("toggleZeroBtn").textContent = labels[zeroMode];

    renderList();
}

// ✏️ **Redigering af en vare**
function startEditWithTranslation(item, cat) {
    numberInput.value = item.number;
    nameInput.value = item.name;
    categorySelect.value = cat.name;
    editingItem = { item, cat };

    isEditing = true; // Sæt redigeringstilstand til "true"
    updateButtonText(); // Opdater knapteksten

    lastFocusedId = item.id;
    numberInput.focus();
}

// ➕ **Tilføj eller opdater vare**
function processItemAction() {
    if (!selectedStore) return alert(translations[currentLang].shop["Select store"]);

    const qty = numberInput.value.trim();
    const name = nameInput.value.trim();
    const catName = categorySelect.value;

    if (qty === "" || isNaN(qty) || qty < 0 || qty > 999) return alert(translations[currentLang].shop["QtyError"]);
    if (name === "" || catName === "") return alert(translations[currentLang].shop["ItemNameError"]);

    const store = getCurrentStore();
    const cat = store.categories.find(c => c.name === catName);

    if (editingItem) {
        const oldCat = editingItem.cat;
        const item = editingItem.item;

        if (oldCat.name !== catName) {
            oldCat.items = oldCat.items.filter(i => i.id !== item.id);
            const newItem = { ...item, number: qty, name, category: catName };
            cat.items.push(newItem);
        } else {
            Object.assign(item, { number: qty, name });
        }

        editingItem = null;
        isEditing = false; // Nulstil redigeringstilstand
        updateButtonText(); // Opdater knapteksten

    } else {
        cat.items.push({ id: crypto.randomUUID(), number: qty, name, price: "", checked: false });
    }

    renderList();
}

// 🔄 **Kør oversættelser ved start**
window.onload = loadTranslations;
