let stores = JSON.parse(localStorage.getItem("stores")) || [];
let selectedStore = localStorage.getItem("selectedStore") || "";
let editingItem = null;
let lastFocusedId = null;
let zeroMode = 0;

const storeSelect = document.getElementById("storeSelect");
const numberInput = document.getElementById("itemNumber");
const nameInput = document.getElementById("itemName");
const categorySelect = document.getElementById("itemCategory");
const filterSelect = document.getElementById("filterCategory");
const list = document.getElementById("list");
const totalDiv = document.getElementById("total");
const addBtn = document.getElementById("addBtn");
const toggleZeroBtn = document.getElementById("toggleZeroBtn");

function saveStores() {
  localStorage.setItem("stores", JSON.stringify(stores));
}

function getCurrentStore() {
  return stores.find(s => s.name === selectedStore);
}

function loadStores() {
  storeSelect.innerHTML = '<option value="">Select store</option>';
  const sorted = [...stores].sort((a, b) => a.name.localeCompare(b.name));
  sorted.forEach(s => {
    const option = document.createElement("option");
    option.value = s.name;
    option.textContent = s.name;
    storeSelect.appendChild(option);
  });
  storeSelect.value = selectedStore;
}

function changeStore() {
  selectedStore = storeSelect.value;
  localStorage.setItem("selectedStore", selectedStore);
  renderCategoryOptions();
  renderList();
}

function renderCategoryOptions() {
  categorySelect.innerHTML = '<option value="">Select category</option>';
  filterSelect.innerHTML = '<option value="">All categories</option>';
  const store = getCurrentStore();
  if (store) {
    const sorted = [...store.categories].sort((a, b) => a.name.localeCompare(b.name));
    sorted.forEach(cat => {
      const opt1 = document.createElement("option");
      opt1.value = cat.name;
      opt1.textContent = cat.name;
      categorySelect.appendChild(opt1);

      const opt2 = document.createElement("option");
      opt2.value = cat.name;
      opt2.textContent = cat.name;
      filterSelect.appendChild(opt2);
    });
  }
}

function addItem() {
  if (!selectedStore) return alert("Select a store first.");
  const qty = numberInput.value.trim();
  const name = nameInput.value.trim();
  const catName = categorySelect.value;

  if (qty === "" || isNaN(qty) || qty < 0 || qty > 999) return alert("Quantity must be 0-999.");
  if (name === "" || catName === "") return alert("Item name and category required.");

  const store = getCurrentStore();
  const cat = store.categories.find(c => c.name === catName);

  if (editingItem) {
    const oldCat = editingItem.cat;
    const item = editingItem.item;
    if (oldCat.name !== catName) {
      oldCat.items = oldCat.items.filter(i => i.id !== item.id);
      const newItem = { ...item, number: qty, name, category: catName };
      cat.items.push(newItem);
    } else {
      Object.assign(item, { number: qty, name });
    }
    editingItem = null;
    addBtn.textContent = "Add Item";
  } else {
    cat.items.push({ id: crypto.randomUUID(), number: qty, name, price: "", checked: false });
  }

  saveStores();
  numberInput.value = "";
  nameInput.value = "";
  categorySelect.value = "";
  renderList();
}

function editItem(item, cat) {
  numberInput.value = item.number;
  nameInput.value = item.name;
  categorySelect.value = cat.name;
  editingItem = { item, cat };
  addBtn.textContent = "Update Item";
  lastFocusedId = item.id;
  numberInput.focus();
}

function toggleCheck(item) {
  item.checked = !item.checked;
  saveStores();
  renderList();
}

function deleteItem(cat, itemId) {
  cat.items = cat.items.filter(i => i.id !== itemId);
  saveStores();
  renderList();
}

function toggleZeroVisibility() {
  zeroMode = (zeroMode + 1) % 3;
  const labels = ["Hide 0", "Only 0", "Show all"];
  toggleZeroBtn.textContent = labels[zeroMode];
  renderList();
}

function renderList() {
  if (!selectedStore) {
    list.innerHTML = "<li>Select a store</li>";
    totalDiv.textContent = "Total: 0.00 kr";
    return;
  }

  list.innerHTML = "";
  const store = getCurrentStore();
  const selectedCategory = filterSelect.value;
  let total = 0;

  const categories = store.categories.slice().sort((a, b) => a.name.localeCompare(b.name));

  [false, true].forEach(checkedState => {
    categories.forEach(cat => {
      if (!selectedCategory || cat.name === selectedCategory) {
        cat.items
          .filter(item => item.checked === checkedState)
          .filter(item => {
            const qty = parseInt(item.number);
            return zeroMode === 0 ||
              (zeroMode === 1 && qty !== 0) ||
              (zeroMode === 2 && qty === 0);
          })
          .sort((a, b) => a.name.localeCompare(b.name))
          .forEach(item => {
            const li = document.createElement("li");
            if (item.checked) li.classList.add("checked");

            const top = document.createElement("div");
            top.className = "top-line";

            const itemLine = document.createElement("div");
            itemLine.className = "item-line";

            const numberSpan = document.createElement("span");
            numberSpan.className = "item-number";
            numberSpan.textContent = item.number;
            numberSpan.dataset.id = item.id;
            numberSpan.tabIndex = 0;
            numberSpan.onclick = () => editItem(item, cat);

            const nameSpan = document.createElement("span");
            nameSpan.className = "item-name";
            nameSpan.textContent = item.name;
            nameSpan.onclick = () => toggleCheck(item);

            itemLine.append(numberSpan, nameSpan);

            const delBtn = document.createElement("button");
            delBtn.className = "del-btn";
            delBtn.textContent = "Delete";
            delBtn.onclick = (e) => {
              e.stopPropagation();
              deleteItem(cat, item.id);
            };

            top.append(itemLine, delBtn);

            const bottom = document.createElement("div");
            bottom.className = "bottom-line";

            const catSpan = document.createElement("span");
            catSpan.textContent = `Category: ${cat.name}`;

            const priceInput = document.createElement("input");
            priceInput.type = "text";
            priceInput.placeholder = "Price";
            priceInput.value = item.price || "";
            priceInput.onchange = (e) => {
              let price = parseFloat(e.target.value.replace(",", "."));
              item.price = isNaN(price) ? "" : price.toFixed(2).replace(".", ",");
              saveStores();
              renderList();
            };

            bottom.append(catSpan, priceInput);
            li.append(top, bottom);
            li.querySelector(".item-number").dataset.id = item.id;
            list.appendChild(li);

            if (item.id === lastFocusedId) {
              requestAnimationFrame(() => {
                li.classList.add("flash");
                setTimeout(() => li.classList.remove("flash"), 2000);
              });
            }

            if (item.checked && item.price) {
              total += parseFloat(item.price.replace(",", ".")) * parseInt(item.number);
            }
          });
      }
    });
  });

  totalDiv.textContent = "Total: " + total.toFixed(2).replace(".", ",") + " kr";
}
