const langCode = 'da';

const phrases = {
  shop: [
    "Heading", "Select store", "Qty", "Item name", "Select category", "Add item",
    "All Categories", "Manage", "Update item", "Hide 0", "Only 0", "Show all",
    "Delete", "Category:", "Price", "Total", "£"
  ],
  cat: [
    "Heading", "Select store", "New store name", "Add Store", "Delete Store",
    "Export", "Import", "Category name", "Add Category", "Update Category",
    "Back", "Edit", "Delete"
  ]
};

const defaults = {
  shop: {
    "Heading": "Shopping list"
  },
  cat: {
    "Heading": "Administration"
  }
};

function buildTable(section, tableId) {
  const table = document.getElementById(tableId);
  table.innerHTML = "";
  phrases[section].forEach((phrase, index) => {
    const row = document.createElement('tr');

    const englishCell = document.createElement('td');
    englishCell.textContent = phrase;
    row.appendChild(englishCell);

    const inputCell = document.createElement('td');
    const input = document.createElement('input');
    input.type = 'text';
    input.dataset.section = section;
    input.dataset.key = phrase;
    input.id = `${section}-${index}`;
    inputCell.appendChild(input);
    row.appendChild(inputCell);

    table.appendChild(row);
  });
}

function saveJson() {
  const data = {
    en: { shop: {}, cat: {} },
    [langCode]: { shop: {}, cat: {} }
  };

  Object.entries(phrases).forEach(([section, keys]) => {
    keys.forEach((phrase, index) => {
      const input = document.getElementById(`${section}-${index}`);
      const value = input.value || "";
      data.en[section][phrase] = phrase;
      data[langCode][section][phrase] = value;
    });
  });

  localStorage.setItem('langBackup', JSON.stringify(data));

  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'lang.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function loadJson() {
  const file = document.getElementById('fileInput').files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function (e) {
    const data = JSON.parse(e.target.result);
    fillInputs(data);
  };
  reader.readAsText(file);
}

function fillInputs(data) {
  const langData = data[langCode] || {};
  Object.entries(phrases).forEach(([section, keys]) => {
    keys.forEach((phrase, index) => {
      const input = document.getElementById(`${section}-${index}`);
      const defaultVal = defaults[section]?.[phrase] || phrase;
      input.value = langData[section]?.[phrase] || defaultVal;
    });
  });
}

window.addEventListener('DOMContentLoaded', () => {
  buildTable('shop', 'shop-table');
  buildTable('cat', 'cat-table');

  const backup = localStorage.getItem('langBackup');
  if (backup) {
    fillInputs(JSON.parse(backup));
  } else {
    Object.entries(phrases).forEach(([section, keys]) => {
      keys.forEach((phrase, index) => {
        const input = document.getElementById(`${section}-${index}`);
        const defaultVal = defaults[section]?.[phrase] || phrase;
        input.value = defaultVal;
      });
    });
  }
});
