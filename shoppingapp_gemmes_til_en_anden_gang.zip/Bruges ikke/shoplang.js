const translations = {
  en: {
    title: "Shopping List",
    shoppingList: "Shopping List",
    selectStore: "Select store",
    quantity: "Qty",
    itemName: "Item name",
    selectCategory: "Select category",
    addItem: "Add Item",
    allCategories: "All categories",
    manage: "Manage",
    toggleZero_hide: "Hide 0",
    toggleZero_show: "Show 0",
    toggleZero_all: "All items",
    totalLabel: "Total:",
    currency: "kr"
  },
  da: {
    title: "Indkøbsliste",
    shoppingList: "Indkøbsliste",
    selectStore: "Vælg butik",
    quantity: "Antal",
    itemName: "Varenavn",
    selectCategory: "Vælg kategori",
    addItem: "Tilføj vare",
    allCategories: "Alle kategorier",
    manage: "Administrer",
    toggleZero_hide: "Skjul 0",
    toggleZero_show: "Vis 0",
    toggleZero_all: "Alle varer",
    totalLabel: "I alt:",
    currency: "kr"
  },
  de: {
    title: "Einkaufsliste",
    shoppingList: "Einkaufsliste",
    selectStore: "Geschäft auswählen",
    quantity: "Menge",
    itemName: "Artikelname",
    selectCategory: "Kategorie wählen",
    addItem: "Artikel hinzufügen",
    allCategories: "Alle Kategorien",
    manage: "Verwalten",
    toggleZero_hide: "0 ausblenden",
    toggleZero_show: "0 anzeigen",
    toggleZero_all: "Alle Artikel",
    totalLabel: "Gesamt:",
    currency: "€"
  }
};

const selectedLang = localStorage.getItem('selectedLang') || 'en';
const t = translations[selectedLang] || translations['en'];

function applyTranslations() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (t[key]) {
      if (el.tagName === "OPTION" && el.value === "") {
        el.text = t[key];
      } else if (el.tagName !== "OPTION") {
        el.textContent = t[key];
      }
    }
  });

  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (t[key]) el.setAttribute('placeholder', t[key]);
  });
}

// Kør første gang
applyTranslations();

// Håndtér toggle-knap med tre tilstande
const toggleBtn = document.getElementById("toggleZeroBtn");
if (toggleBtn) {
  const toggleStates = ["toggleZero_hide", "toggleZero_show", "toggleZero_all"];
  let stateIndex = 0;

  toggleBtn.textContent = t[toggleStates[stateIndex]];

  toggleBtn.addEventListener("click", () => {
    stateIndex = (stateIndex + 1) % toggleStates.length;
    toggleBtn.textContent = t[toggleStates[stateIndex]];
  });
}

// 🎯 Brug MutationObserver til at holde øje med <select> og re-oversæt <option value="">
const observer = new MutationObserver(() => {
  document.querySelectorAll('select').forEach(select => {
    const firstOption = select.querySelector('option[value=""][data-i18n]');
    if (firstOption) {
      const key = firstOption.getAttribute('data-i18n');
      if (t[key]) firstOption.text = t[key];
    }
  });
});

// Overvåg ændringer i dropdowns
document.querySelectorAll('select').forEach(select => {
  observer.observe(select, { childList: true, subtree: true });
});
