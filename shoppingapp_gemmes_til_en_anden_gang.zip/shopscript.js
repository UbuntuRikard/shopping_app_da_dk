let butikker = JSON.parse(localStorage.getItem("butikker")) || [];
let selectedButik = localStorage.getItem("selectedButik") || "";
let editingItem = null;
let lastFocusedId = null;
let zeroMode = 0;

const butikSelect = document.getElementById("butikSelect");
const numberInput = document.getElementById("itemNumber");
const nameInput = document.getElementById("itemName");
const categorySelect = document.getElementById("itemCategory");
const filterSelect = document.getElementById("filterCategory");
const list = document.getElementById("list");
const totalDiv = document.getElementById("total");
const addBtn = document.getElementById("addBtn");
const toggleZeroBtn = document.getElementById("toggleZeroBtn");

function saveButikker() {
  localStorage.setItem("butikker", JSON.stringify(butikker));
}

function loadButikker() {
  butikSelect.innerHTML = '<option value="">Vælg butik</option>';
  const sorteredeButikker = [...butikker].sort((a, b) => a.navn.localeCompare(b.navn));
  sorteredeButikker.forEach(b => {
    const option = document.createElement("option");
    option.value = b.navn;
    option.textContent = b.navn;
    butikSelect.appendChild(option);
  });
  butikSelect.value = selectedButik;
}

function changeButik() {
  selectedButik = butikSelect.value;
  localStorage.setItem("selectedButik", selectedButik);
  renderCategoryOptions();
  renderList();
}

function getCurrentButik() {
  return butikker.find(b => b.navn === selectedButik);
}

function renderCategoryOptions() {
  categorySelect.innerHTML = '<option value="">Vælg kategori</option>';
  filterSelect.innerHTML = '<option value="">Alle kategorier</option>';
  const butik = getCurrentButik();
  if (butik) {
    const sorteredeKategorier = [...butik.kategorier].sort((a, b) => a.navn.localeCompare(b.navn));
    sorteredeKategorier.forEach(cat => {
      const option1 = document.createElement("option");
      option1.value = cat.navn;
      option1.textContent = cat.navn;
      categorySelect.appendChild(option1);

      const option2 = document.createElement("option");
      option2.value = cat.navn;
      option2.textContent = cat.navn;
      filterSelect.appendChild(option2);
    });
  }
}

function addItem() {
  if (!selectedButik) {
    alert("Vælg en butik først.");
    return;
  }

  const number = numberInput.value.trim();
  const name = nameInput.value.trim();
  const categoryName = categorySelect.value;

  if (number === "" || isNaN(number) || number < 0 || number > 999) {
    alert("Antal skal være mellem 0 og 999.");
    return;
  }
  if (name === "" || categoryName === "") {
    alert("Varenavn og kategori skal udfyldes.");
    return;
  }

  const butik = getCurrentButik();
  const newCategory = butik.kategorier.find(c => c.navn === categoryName);

  if (editingItem) {
    const oldCat = editingItem.cat;
    const item = editingItem.item;
    if (oldCat.navn !== categoryName) {
      oldCat.varer = oldCat.varer.filter(v => v.id !== item.id);
      const newItem = { ...item, number, name, category: categoryName };
      newCategory.varer.push(newItem);
    } else {
      Object.assign(item, { number, name });
    }
    editingItem = null;
    addBtn.textContent = "Tilføj Vare";
  } else {
    newCategory.varer.push({ id: crypto.randomUUID(), number, name, price: "", checked: false });
  }

  saveButikker();
  numberInput.value = "";
  nameInput.value = "";
  categorySelect.value = "";
  renderList();

  if (lastFocusedId) {
    const el = document.querySelector(`[data-id="${lastFocusedId}"]`);
    if (el) el.focus();
    lastFocusedId = null;
  }
}

function editItem(item, cat) {
  numberInput.value = item.number;
  nameInput.value = item.name;
  categorySelect.value = cat.navn;
  editingItem = { item, cat };
  addBtn.textContent = "Opdater Vare";
  lastFocusedId = item.id;
  numberInput.focus();
}

function toggleCheck(item) {
  item.checked = !item.checked;
  saveButikker();
  renderList();
}

function deleteItem(cat, itemId) {
  cat.varer = cat.varer.filter(v => v.id !== itemId);
  saveButikker();
  renderList();
}

function toggleZeroVisibility() {
  zeroMode = (zeroMode + 1) % 3;
  const labels = ["Skjul 0", "Kun 0", "Vis alle"];
  toggleZeroBtn.textContent = labels[zeroMode];
  renderList();
}

function renderList() {
  if (!selectedButik) {
    list.innerHTML = "<li>Vælg en butik</li>";
    totalDiv.textContent = "I alt: 0,00 kr";
    return;
  }

  list.innerHTML = "";
  const butik = getCurrentButik();
  const selectedCategory = filterSelect.value;
  let total = 0;

  const categories = butik.kategorier.slice().sort((a, b) => a.navn.localeCompare(b.navn));

  [false, true].forEach(checkedState => {
    categories.forEach(cat => {
      if (!selectedCategory || cat.navn === selectedCategory) {
        cat.varer
          .filter(item => item.checked === checkedState)
          .filter(item => {
            const antal = parseInt(item.number);
            return zeroMode === 0 ||
              (zeroMode === 1 && antal !== 0) ||
              (zeroMode === 2 && antal === 0);
          })
          .sort((a, b) => a.name.localeCompare(b.name))
          .forEach(item => {
            const li = document.createElement("li");
            if (item.checked) li.classList.add("checked");

            const top = document.createElement("div");
            top.className = "top-line";

            const itemLine = document.createElement("div");
            itemLine.className = "item-line";

            const numberSpan = document.createElement("span");
            numberSpan.className = "item-number";
            numberSpan.textContent = item.number;
            numberSpan.dataset.id = item.id;
            numberSpan.tabIndex = 0;
            numberSpan.onclick = () => editItem(item, cat);

            const nameSpan = document.createElement("span");
            nameSpan.className = "item-name";
            nameSpan.textContent = item.name;
            nameSpan.onclick = () => toggleCheck(item);

            itemLine.append(numberSpan, nameSpan);

            const delBtn = document.createElement("button");
            delBtn.className = "del-btn";
            delBtn.textContent = "Slet";
            delBtn.onclick = (e) => {
              e.stopPropagation();
              deleteItem(cat, item.id);
            };

            top.append(itemLine, delBtn);

            const bottom = document.createElement("div");
            bottom.className = "bottom-line";

            const categorySpan = document.createElement("span");
            categorySpan.textContent = `Kategori: ${cat.navn}`;

            const priceInput = document.createElement("input");
            priceInput.type = "text";
            priceInput.placeholder = "Pris";
            priceInput.value = item.price || "";
            priceInput.onchange = (e) => {
              let price = parseFloat(e.target.value.replace(",", "."));
              item.price = isNaN(price) ? "" : price.toFixed(2).replace(".", ",");
              saveButikker();
              renderList();
            };

            bottom.append(categorySpan, priceInput);
            li.append(top, bottom);
            li.querySelector(".item-number").dataset.id = item.id;
            list.appendChild(li);

            if (item.id === lastFocusedId) {
              requestAnimationFrame(() => {
                li.classList.add("flash");
                setTimeout(() => li.classList.remove("flash"), 2000);
              });
            }

            if (item.checked && item.price) {
              total += parseFloat(item.price.replace(",", ".")) * parseInt(item.number);
            }
          });
      }
    });
  });

  totalDiv.textContent = "I alt: " + total.toFixed(2).replace(".", ",") + " kr";
}
