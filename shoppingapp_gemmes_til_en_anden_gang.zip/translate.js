// translate.js

// Enkelt oversættelse med fallback
function t(key, section = null) {
  const trans = window.translations || {};
  const fallback = {};

  if (section) {
    return trans[section]?.[key] || fallback[section]?.[key] || key;
  }

  return (
    trans.shop?.[key] ||
    trans.cat?.[key] ||
    fallback.shop?.[key] ||
    fallback.cat?.[key] ||
    key
  );
}

// Gæt hvilken sektion ('shop' eller 'cat') elementet hører til
function getSectionFromElement(el) {
  if (location.pathname.includes('category')) return 'cat';
  return 'shop';
}

// Oversætter hele DOM'en
function applyTranslations() {
  // 1. Tekstindhold (beskyt dynamisk indhold)
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    const section = getSectionFromElement(el);

    // Oversæt kun hvis elementet ikke har børn (fx <option>, <ul>, <select> mv.)
    if (el.children.length === 0) {
      el.textContent = t(key, section);
    }
  });

  // 2. Placeholder-attributter
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    const section = getSectionFromElement(el);
    el.setAttribute('placeholder', t(key, section));
  });

  // 3. <title>
  const titleEl = document.querySelector('title[data-i18n]');
  if (titleEl) {
    const titleKey = titleEl.getAttribute('data-i18n');
    const section = getSectionFromElement(titleEl);
    document.title = t(titleKey, section);
  }
}
